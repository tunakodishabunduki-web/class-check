import { useAuth } from "@/contexts/AuthContext";
import { Suspense, lazy } from "react";
import { Navigate } from "react-router-dom";

const TeacherDashboard = lazy(() => import("./TeacherDashboard"));
const StudentDashboard = lazy(() => import("./StudentDashboard"));

const DashboardLoading = () => (
  <div className="flex min-h-screen items-center justify-center bg-background">
    <p className="text-muted-foreground">Loading...</p>
  </div>
);

const Dashboard = () => {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex min-h-screen items-center justify-center bg-background"><p className="text-muted-foreground">Loading...</p></div>;
  if (!user) return <Navigate to="/" replace />;
  return (
    <Suspense fallback={<DashboardLoading />}>
      {user.role === "teacher" ? <TeacherDashboard /> : <StudentDashboard />}
    </Suspense>
  );
};

export default Dashboard;
