-- Performance indexes for dashboard/auth queries and RLS checks

CREATE INDEX IF NOT EXISTS idx_profiles_user_id
  ON public.profiles (user_id);

CREATE INDEX IF NOT EXISTS idx_attendance_codes_teacher_id_created_at
  ON public.attendance_codes (teacher_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_attendance_codes_code
  ON public.attendance_codes (code);

CREATE INDEX IF NOT EXISTS idx_attendance_codes_code_teacher_id
  ON public.attendance_codes (code, teacher_id);

CREATE INDEX IF NOT EXISTS idx_attendance_codes_expires_at
  ON public.attendance_codes (expires_at);

CREATE INDEX IF NOT EXISTS idx_attendance_records_student_id_submitted_at
  ON public.attendance_records (student_id, submitted_at DESC);

CREATE INDEX IF NOT EXISTS idx_attendance_records_code_submitted_at
  ON public.attendance_records (code, submitted_at DESC);

CREATE INDEX IF NOT EXISTS idx_attendance_records_student_id_code
  ON public.attendance_records (student_id, code);
