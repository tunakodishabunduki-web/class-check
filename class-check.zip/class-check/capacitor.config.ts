import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.classcheck.app',
  appName: 'CLASS-CHECK',
  webDir: 'dist'
};

export default config;
